import { Navigate, Outlet, useLocation } from "react-router-dom";
import { isAuthenticated, getUser } from "../utils/auth";

const ProtectedRoute = ({ allowedRoles = [] }) => {

    const location = useLocation();

    if (!isAuthenticated()) {

        return (
            <Navigate
                to="/signin"
                state={{ from: location }}
                replace
            />
        );

    }

    if (allowedRoles.length === 0) {

        return <Outlet />;

    }

    const user = getUser();

    const role = String(
        user?.role || user?.user_role || ""
    ).toLowerCase();

    const allowed = allowedRoles.map(
        (item) => String(item).toLowerCase()
    );

    if (!allowed.includes(role)) {

        return (
            <Navigate
                to="/"
                replace
            />
        );

    }

    return <Outlet />;
};

export default ProtectedRoute;