import { Container, Row, Col, Form, Button } from "react-bootstrap";
import WorkerProfileCard from "../../components/WorkerProfileCard";

function WorkerProfile() {

    const worker = {
        name: "John Kamau",
        position: "Senior Detailer",
        phone: "0712345678",
        email: "john@bluewave.com"
    };

    return (

        <Container className="py-5">

            <Row>

                <Col lg={4}>
                    <WorkerProfileCard worker={worker}/>
                </Col>

                <Col lg={8}>

                    <h2 className="fw-bold text-primary mb-4">
                        Worker Profile
                    </h2>

                    <Form>

                        <Form.Group className="mb-3">
                            <Form.Label>Full Name</Form.Label>
                            <Form.Control defaultValue={worker.name}/>
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Email</Form.Label>
                            <Form.Control defaultValue={worker.email}/>
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Phone</Form.Label>
                            <Form.Control defaultValue={worker.phone}/>
                        </Form.Group>

                        <Button variant="primary">
                            Save Changes
                        </Button>

                    </Form>

                </Col>

            </Row>

        </Container>

    );

}

export default WorkerProfile;