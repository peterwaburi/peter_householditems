import { Container } from "react-bootstrap";
import JobCard from "../../components/JobCard";

function AssignedJobs() {

    const jobs = [

        {
            customer:"Peter Waburi",
            service:"Full Detailing",
            vehicle:"Ford Ranger",
            time:"09:00 AM",
            status:"Assigned",
            color:"primary"
        },

        {
            customer:"Jane",
            service:"Interior Cleaning",
            vehicle:"Toyota Prado",
            time:"11:30 AM",
            status:"In Progress",
            color:"warning"
        }

    ];

    return(

        <Container className="py-5">

            <h2 className="fw-bold text-primary mb-4">
                Assigned Jobs
            </h2>

            {jobs.map((job,index)=>(

                <JobCard
                    key={index}
                    job={job}
                />

            ))}

        </Container>

    );

}

export default AssignedJobs;