import api from "./api";

export const getDashboardSummary = () => {
    return api.get("/dashboard/summary");
};

export const getManagerDashboard = () => {
    return api.get("/manager/dashboard");
};

export const getWorkerDashboard = () => {
    return api.get("/worker/dashboard");
};

export const getCustomerDashboard = () => {
    return api.get("/customer/dashboard");
};