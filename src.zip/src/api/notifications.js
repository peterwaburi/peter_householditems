import api from "./api";

export const getNotifications = () => {
    return api.get("/notifications");
};

export const createNotification = (data) => {
    return api.post("/notifications", data);
};

export const markNotificationRead = (id) => {
    return api.patch(`/notifications/${id}/read`);
};

export const deleteNotification = (id) => {
    return api.delete(`/notifications/${id}`);
};