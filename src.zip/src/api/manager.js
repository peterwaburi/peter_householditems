import api from "./api";

export const getManagerDashboard = () =>
    api.get("/manager/dashboard");

export const getAnalytics = () =>
    api.get("/analytics/summary");

export const getReports = () =>
    api.get("/reports/summary");

export const getStatistics = () =>
    api.get("/statistics");

export const getSearch = (keyword) =>
    api.get(`/search?q=${encodeURIComponent(keyword)}`);