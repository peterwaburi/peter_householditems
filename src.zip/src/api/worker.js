import api from "./api";

export const getWorkerDashboard = () =>
    api.get("/worker/dashboard");

export const getAttendance = () =>
    api.get("/attendance");

export const getSchedules = () =>
    api.get("/schedules");

export const getBookings = () =>
    api.get("/bookings");