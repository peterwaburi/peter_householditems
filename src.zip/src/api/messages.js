import api from "./api";

export const getMessages = () => {
    return api.get("/messages");
};

export const getMessage = (id) => {
    return api.get(`/messages/${id}`);
};

export const sendMessage = (data) => {
    return api.post("/messages", data);
};

export const deleteMessage = (id) => {
    return api.delete(`/messages/${id}`);
};