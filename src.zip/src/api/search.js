import api from "./api";

export const search = (query) => {
    return api.get(
        `/search?q=${encodeURIComponent(query)}`
    );
};